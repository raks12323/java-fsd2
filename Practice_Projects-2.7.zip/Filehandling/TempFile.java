package Filehandling;
import java.io.File;
public class TempFile {
	 
	    public static void main(String[] args) throws Exception
	    {
	        
	        File file = File.createTempFile(
	            "temp", ".txt",
	            new File(
	                "C:"));
	
	        System.out.println(file.getAbsolutePath());
	        System.out.print( "C:");
	 
	        // Deleting the file while exiting the program
	       // file.deleteOnExit();
	    }
	}

